﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_No._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private double Operación(string simbolo)
        {
            double num1 = 0, num2 = 0, total = 0;
            num1 = Convert.ToDouble(textBox1.Text);
            num2 = Convert.ToDouble(textBox2.Text);
            if (simbolo == "+")
            {
                total = num1 + num2;
                textBox3.Text = total.ToString();
            }
            if (simbolo == "-")
            {
                total = num1 - num2;
                textBox3.Text = total.ToString();
            }
            if (simbolo == "/")
            {
                total = num1 / num2;
                textBox3.Text = total.ToString();
            }
            if (simbolo == "*")
            {
                total = num1 * num2;
                textBox3.Text = total.ToString();
            }
            return total;
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            Operación("+");
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            Operación("-");
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            Operación("*");
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            Operación("/");
        }
    }
}
